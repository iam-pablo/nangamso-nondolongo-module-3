package com.example.e_tours

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
