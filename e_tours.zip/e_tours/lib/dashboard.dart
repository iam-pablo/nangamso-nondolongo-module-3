import 'dart:async';
import 'package:e_tours/tour_dets.dart';
import 'package:flutter/material.dart';

class DashBoard extends StatefulWidget{
  @override
  State createState() => DashBoardState();
}

class DashBoardState extends State<DashBoard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
      ),
      body: Column(
        children: <Widget> [
          Text ('Please check out Tour packes below',
            textAlign: TextAlign.left,),
          Row(
            children: const [
              Text('Tour 1',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
              Text(
                'Location X'
              )
            ],
          ),

          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [
                const TextButton(
                  // style: ButtonStyle(
                  //   backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                  //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  // ),
                    onPressed: _btnPressed, child: Text('View')),
              ]
          ),
        ],
      ),
    );
  }
}

void _btnPressed() {
  Navigator.of(context).push(
      MaterialPageRoute(
          builder: (_) => TourDets())
  );
}