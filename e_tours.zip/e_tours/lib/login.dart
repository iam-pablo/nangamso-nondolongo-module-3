import 'dart:async';
import 'dart:js';
import 'package:e_tours/dashboard.dart';
import 'package:e_tours/userprofile.dart';
import 'package:flutter/material.dart';

class LogIn extends StatefulWidget{
  @override
  State createState() => LogInState();
}

class LogInState extends State<LogIn> {
  // const LogInState({Key? key,}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log in or Register'),
      ),
      body: Column(
        children: <Widget> [
          Row(
            children: const [
              Text('Username',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                decoration: InputDecoration(
                labelText: 'Username',
              )
            )
          ],
        ),
          Row(
          children: const [
            Text('Password',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            TextField(
                decoration: InputDecoration(
                  labelText: '*******',
                )
            )
          ],
            ),
          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [
                  const TextButton(onPressed: _btnPressed, child: Text('Log In')),
                  const TextButton(onPressed: _btnPressedD, child: Text('Register')),
              ]
          ),
      ],
      ),
    );
  }
}

void _btnPressed() {
  Navigator.of(context).push(
    MaterialPageRoute(
        builder: (_) => DashBoard())
  );
}
void _btnPressedD() {
  Navigator.of(context).push(
      MaterialPageRoute(
          builder: (_) => UserProfile())
  );
}