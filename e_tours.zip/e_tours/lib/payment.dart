import 'dart:async';
import 'package:flutter/material.dart';

class Payment extends StatefulWidget{
  @override
  State createState() => PaymentState();
}

class PaymentState extends State<Payment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment Information',
          style: TextStyle(
            fontSize: 20,
          ),),
      ),
      body: Column(
        children: <Widget> [
          Text ('Card',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('Card number',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: '9876 5649 5647 256',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Expiry date',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: '17/58',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('CSV',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: '568',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Name on Card',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: 'Micheal Nyathi',
                  )
              )
            ],
          ),
         TextButton(
            //mainAxisAlignment: MainAxisAlignment.center,
            // style: ButtonStyle(
            //   backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
            //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            // ),
              onPressed: null, child: Text('Pay with card'),
        ),
          Text ('Coupon',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('Coupon number',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: '7569-5689-ADS5',
                  )
              )
            ],
          ),

          TextButton(
                //mainAxisAlignment: MainAxisAlignment.center,
                  // style: ButtonStyle(
                  //   backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                  //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  // ),
                    onPressed: null, child: Text('Pay with coupon'),

          ),
        ],
      ),
    );
  }
}