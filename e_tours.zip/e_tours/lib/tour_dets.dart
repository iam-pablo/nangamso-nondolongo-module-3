import 'dart:async';
import 'package:e_tours/payment.dart';
import 'package:flutter/material.dart';

class TourDets extends StatefulWidget{
  @override
  State createState() => TourDetsState();
}

class TourDetsState extends State<TourDets> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tour information',
          style: TextStyle(
            fontSize: 20,
          ),),
      ),
      body: Column(
        children: <Widget> [
          Text ('Personal Information',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('From:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                'Point A'
                  ),

            ],
          ),
          Row(
            children: const [
              Text('To:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                  'Point B'
              )
            ],
          ),
          Row(
            children: const [
              Text('Distance Covered:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                  'X Km'
              )
            ],
          ),

          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [
                const TextButton(
                  // style: ButtonStyle(
                  //   backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                  //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  // ),
                    onPressed: null, child: Text('Book')),
                const TextButton(
                  // style: ButtonStyle(
                  //   backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                  //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  // ),
                    onPressed: null, child: Text('Back')),
              ]
          ),
        ],
      ),
    );
  }
}

void _btnPressed() {
  Navigator.of(context).push(
      MaterialPageRoute(
          builder: (_) => Payment())
  );
}