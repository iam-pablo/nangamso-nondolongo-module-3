import 'dart:async';
import 'package:flutter/material.dart';

class UserProfile extends StatefulWidget{
  @override
  State createState() => UserProfileState();
}

class UserProfileState extends State<UserProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit your user profile',
        style: TextStyle(
          fontSize: 20,
        ),),
      ),
      body: Column(
        children: <Widget> [
          Text ('Personal Information',
          textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('First name',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: 'First name',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Last name',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: 'Last name',
                  )
              )
            ],
          ),
          Text ('Account Information',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('User account',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: 'oneforall@mha.com',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Password',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: 'PlusUltr@',
                  )
              )
            ],
          ),
          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [
                const TextButton(
                  // style: ButtonStyle(
                  //   backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                  //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  // ),
                    onPressed: null, child: Text('Save')),
                const TextButton(
                    // style: ButtonStyle(
                    //   backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                    //   foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    // ),
                    onPressed: null, child: Text('Cancel')),
              ]
          ),
        ],
      ),
    );
  }
}